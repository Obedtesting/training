# AI Full Stack Challenge — IT Access Requests

Test from Obed

The task is in CHALLENGE.md. Replace this file with your own README, as CHALLENGE.md asks.
